import { randomBytes, scryptSync, timingSafeEqual, createHmac } from "node:crypto";

const N = 16384, R = 8, P = 1, KEYLEN = 64;

export function hashPassword(password: string): string {
  if (password.length < 12) throw new Error("password must be at least 12 characters");
  const salt = randomBytes(16);
  const h = scryptSync(password, salt, KEYLEN, { N, r: R, p: P });
  return `scrypt$${N}$${R}$${P}$${salt.toString("base64url")}$${h.toString("base64url")}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const parts = stored.split("$");
  if (parts.length !== 6 || parts[0] !== "scrypt") return false;
  const [, n, r, p, salt, hash] = parts;
  const expected = Buffer.from(hash, "base64url");
  const actual = scryptSync(password, Buffer.from(salt, "base64url"), expected.length, { N: +n, r: +r, p: +p });
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

export interface TokenPayload { sub: string; role: "user" | "admin"; iat: number; exp: number }
const b64 = (o: unknown) => Buffer.from(JSON.stringify(o)).toString("base64url");

function mac(data: string, secret: string) {
  if (Buffer.byteLength(secret) < 32) throw new Error("secret must be at least 32 bytes");
  return createHmac("sha256", secret).update(data).digest();
}

export function signToken(sub: string, role: TokenPayload["role"], secret: string, ttlSec: number, nowSec = Math.floor(Date.now() / 1000)): string {
  const head = b64({ alg: "HS256", typ: "JWT" });
  const body = b64({ sub, role, iat: nowSec, exp: nowSec + ttlSec } satisfies TokenPayload);
  return `${head}.${body}.${mac(`${head}.${body}`, secret).toString("base64url")}`;
}

export function verifyToken(token: string, secret: string, nowSec = Math.floor(Date.now() / 1000)): TokenPayload | null {
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  try {
    const header = JSON.parse(Buffer.from(parts[0], "base64url").toString());
    if (header.alg !== "HS256") return null; // reject "none" and alg confusion
    const sig = Buffer.from(parts[2], "base64url");
    const good = mac(`${parts[0]}.${parts[1]}`, secret);
    if (sig.length !== good.length || !timingSafeEqual(sig, good)) return null;
    const p = JSON.parse(Buffer.from(parts[1], "base64url").toString()) as TokenPayload;
    if (typeof p.exp !== "number" || p.exp <= nowSec) return null;
    if (p.role !== "user" && p.role !== "admin") return null;
    return p;
  } catch { return null; }
}
