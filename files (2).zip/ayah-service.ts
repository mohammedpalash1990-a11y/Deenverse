import { createHash } from "node:crypto";
import { parseAyahRef } from "./ayah-contract.ts";

export interface Provenance {
  sourceId: string;
  edition: string;
  license: string;
  approved: boolean;
  textSha256: string; // sha256 (hex) of the UTF-8 bytes of `arabic` exactly as stored
}
export interface AyahRecord { surah: number; ayah: number; arabic: string; provenance: Provenance }
export interface AyahRepository {
  ayahCount(surah: number): Promise<number | null>;
  find(surah: number, ayah: number): Promise<AyahRecord | null>;
}

const json = (status: number, body: unknown) =>
  new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });

export const sha256Hex = (s: string) => createHash("sha256").update(Buffer.from(s, "utf8")).digest("hex");

/**
 * Fail-closed handler for GET /api/v1/ayah/:surah/:ayah.
 * - no repository      -> 503 (never fabricate content)
 * - unapproved source  -> 503
 * - hash mismatch      -> 502 integrity_rejected
 * Text is returned byte-for-byte; it is never normalised or modified here.
 */
export function createAyahHandler(repo: AyahRepository | null) {
  return async function handle(req: Request): Promise<Response> {
    if (req.method !== "GET") return json(405, { error: "method_not_allowed" });
    const m = /^\/api\/v1\/ayah\/([^/]+)\/([^/]+)\/?$/.exec(new URL(req.url).pathname);
    if (!m) return json(404, { error: "not_found" });
    const ref = parseAyahRef(m[1], m[2]);
    if (!ref.ok) return json(400, { error: ref.code, message: ref.message });
    if (!repo) return json(503, { error: "content_source_unavailable" });

    const count = await repo.ayahCount(ref.value.surah);
    if (count === null) return json(503, { error: "catalogue_unavailable" });
    if (ref.value.ayah > count) return json(404, { error: "ayah_out_of_range" });

    const rec = await repo.find(ref.value.surah, ref.value.ayah);
    if (!rec) return json(404, { error: "ayah_not_found" });
    if (!rec.provenance.approved) return json(503, { error: "source_not_approved" });
    if (sha256Hex(rec.arabic) !== rec.provenance.textSha256) return json(502, { error: "integrity_rejected" });
    return json(200, { surah: rec.surah, ayah: rec.ayah, arabic: rec.arabic, provenance: { sourceId: rec.provenance.sourceId, edition: rec.provenance.edition, license: rec.provenance.license } });
  };
}
