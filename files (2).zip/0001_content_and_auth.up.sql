-- Schema only. Contains NO Quran text. Content is loaded only from an approved, verified source.
BEGIN;

CREATE TABLE content_sources (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name         text NOT NULL,
  edition      text NOT NULL,
  version      text NOT NULL,
  attribution  text NOT NULL,
  license      text NOT NULL,
  approved     boolean NOT NULL DEFAULT false,
  approved_by  text,
  approved_at  timestamptz,
  created_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (name, edition, version),
  CONSTRAINT approval_requires_reviewer CHECK (NOT approved OR (approved_by IS NOT NULL AND approved_at IS NOT NULL))
);

CREATE TABLE surahs (
  number      smallint PRIMARY KEY CHECK (number BETWEEN 1 AND 114),
  ayah_count  smallint CHECK (ayah_count IS NULL OR ayah_count >= 1)
);

CREATE TABLE ayahs (
  id            bigserial PRIMARY KEY,
  surah_number  smallint NOT NULL REFERENCES surahs(number),
  ayah_number   smallint NOT NULL CHECK (ayah_number >= 1),
  source_id     uuid NOT NULL REFERENCES content_sources(id),
  arabic        text NOT NULL,
  text_sha256   char(64) NOT NULL CHECK (text_sha256 ~ '^[0-9a-f]{64}$'),
  UNIQUE (surah_number, ayah_number, source_id)
);

CREATE FUNCTION ayahs_immutable() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF NEW.arabic IS DISTINCT FROM OLD.arabic OR NEW.text_sha256 IS DISTINCT FROM OLD.text_sha256 THEN
    RAISE EXCEPTION 'ayah text is immutable; re-import from a verified source instead';
  END IF;
  RETURN NEW;
END $$;
CREATE TRIGGER ayahs_no_text_update BEFORE UPDATE ON ayahs FOR EACH ROW EXECUTE FUNCTION ayahs_immutable();

CREATE TABLE users (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  email          text NOT NULL,
  password_hash  text NOT NULL,
  role           text NOT NULL DEFAULT 'user' CHECK (role IN ('user','admin')),
  created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX users_email_lower_key ON users (lower(email));

COMMIT;
