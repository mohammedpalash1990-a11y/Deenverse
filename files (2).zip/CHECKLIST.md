# Status checklist (source of truth: only what was actually run)

Environment: Node v22.23.4, no network, no repo checkout, no PostgreSQL.
Repo access: root page, README, package.json, vitest.config.ts readable; backend/, src/, docs/, workflows unreadable (GitHub /tree/ blocked).

| Item | Implemented | Tested | Passed | Blocked / note |
|---|---|---|---|---|
| Artifact SHA-256 verifier + 11 tests | not in this env | no | no evidence | code not visible on `main`; not recreated to avoid conflict |
| Surah/Ayah completeness checker | not in this env | no | no evidence | same |
| Ayah param validation (`ayah-contract.ts`) | yes | yes | yes (node:test) | per-surah bounds delegated to verified catalogue |
| Ayah API handler (`ayah-service.ts`) | yes | yes | yes (node:test, fake repo) | not wired to Next.js routes or a real DB |
| Auth: scrypt + HMAC tokens (`auth.ts`) | yes | yes | yes (node:test) | no login/register endpoints, no rate limiting, no refresh/revocation |
| DB migration up/down | yes | static checks only | static checks only | NOT executed on PostgreSQL (none available) |
| Proposed CI (`ci/proposed-ci.yml`) | yes | YAML parse only | parse only | NOT run on GitHub; must reconcile with existing workflows |
| npm ci / build / typecheck / full suite | - | no | no | no network |
| npm audit | - | no | no | no network |
| PostgreSQL integration tests | - | no | no | no network, no postgres |
| zod / sqlite3 upgrade | no | no | no | neither is in root package.json; needs backend/ manifest + lockfile |
| Content source approval | no | no | no | requires human review; no Quran text added anywhere |
